import React from 'react';
import { Route, Routes } from 'react-router-dom';

// __ __ Style Libaries/Components __ __ //
import TopBarProgress from 'react-topbar-progress-indicator';
import './assets/css/index.css';
// import "./assets/css/theme.scss";
import "./assets/css/responsive.scss";

// __ __ Components/Helpers __ __ //
import Layout from './components/layout/Layout.jsx';
import AppLayout from './components/layout/AppLayout';
import ProtectedRoute from './components/layout/ProtectedRoute/ProtectedRoute';
const Home = React.lazy(() => import("./components/main/Home/Home.jsx"));
const Dashboard = React.lazy(() => import("./components/main/Dashboard/Dashboard.jsx"));
const Login = React.lazy(() => import("./components/auth/Login/Login"));
const Register = React.lazy(() => import("./components/auth/Register/Register"));
const NoPageFound = React.lazy(() => import("./components/layout/NoPageFound/NoPageFound.jsx"));



const App = () => {
	return (
		<React.Suspense fallback={<TopBarProgress />}>
			<Routes>
				{/* Guest routes here */}
				<Route path="/" element={<Layout />}>
					<Route index element={<Home />} />
					<Route path="*" element={<NoPageFound />} />
					{/* Add your public routes here eg. <Route path="example" element={<Component />} /> */}
				</Route>
				{/* Auth routes here */}
				<Route path="/app" element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
					<Route index element={<Dashboard />} />
					<Route path="*" element={<NoPageFound />} />
					{/* Add your protected routes here eg. <Route path="example" element={<Component />} /> */}
				</Route>
				<Route path="login" element={<Login />} />
				<Route path="register" element={<Register />} />
			</Routes>
		</React.Suspense>
	);
}

export default App;
