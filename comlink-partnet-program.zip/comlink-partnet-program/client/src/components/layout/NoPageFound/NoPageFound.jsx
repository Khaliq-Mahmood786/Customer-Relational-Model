import React from 'react'

const NoPageFound = () => {
  return (
    <div>NoPageFound</div>
  )
}

export default NoPageFound