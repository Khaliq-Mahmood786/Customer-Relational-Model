import React, { useState, useEffect } from "react";

const Header = () => {
  return <p>Headers</p>;
};

export default Header;
