import React from "react";

const Footer = () => {
  return <p>Footer</p>;
};

export default Footer;
