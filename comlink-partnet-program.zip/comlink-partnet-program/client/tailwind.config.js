module.exports = {
    content: [
      "./src/**/*.{js,jsx,ts,tsx}",
    ],
    theme: {
      extend: {
        fontSize: {
          '1xl': '22px',
        },
        margin: {
          '15': '60px',
        },
        screens: {
          'xm': '576px',
          'sm': '768px',
          'cmd': '992px',
        },
      },
    },
    plugins: [],
}