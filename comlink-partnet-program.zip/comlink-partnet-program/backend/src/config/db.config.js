const mongoose = require('mongoose');

const connectDb = async () => {
    try {
      const db =  await mongoose.connect('mongodb://127.0.0.1:27017/Comlink-Partner-Program');
        console.log(`MongoDB connected ${db.connection.host}`)
    } catch (error) {
        console.log('MongoDB connection error:', error.message);
    }
}
module.exports = connectDb;
