const debug = require("debug")
module.exports.debugRequest = debug('Comlink-Partner-Program:Request')
module.exports.debugResponse = debug('Comlink-Partner-Program:Response')
module.exports.debugError = debug('Comlink-Partner-Program:Error')
