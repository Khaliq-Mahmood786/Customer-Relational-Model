const SocailMedia =require("../models/socialModels")
exports.create = async (req, res, next) => {
 
    try {
      let { url } = payload;
     
      let { permissionId } = payload;
      await Character.create({});

      return res.send({

        success: true,
        message: "Url has been created successfully",
        admin: responseObject,
      });
    } catch (error) {
       next(error);
    }
  };
  exports.get = async (req, res, next) => {
 
    try {
      let { urlid } = payload;
     
      await Character.findOne({});

      return res.send({

        success: true,
        message: "data has been feteched successfully",
      });
    } catch (error) {
       next(error);
    }
  };
  exports.index = async (req, res, next) => {
 
    try {
      let { urlid } = payload;
     
      await Character.find({});

      return res.send({

        success: true,
        message: "Url has been feteched successfully",
      });
    } catch (error) {
       next(error);
    }
  };
  exports.update = async (req, res, next) => {
    try {
      let { urlid } = payload;
     
      await Character.find({});

      return res.send({
        success: true,
        message: "Url has been feteched successfully",
      });
    } catch (error) {
       next(error);
    }
  };