const mongoose = require("mongoose");
/**
 * Soical Media models 
 * @private
 */
const SocialMediaSchema = new mongoose.Schema(
  {
    ownerIdId: { type: mongoose.ObjectId, required: true },
    name: { type:string,required: true },
    type: { type: String, required: true },
    Url: { type: String},
  },
  { timestamps: true}
);
/**
 * @typedef SocailMedia
 */
module.exports = mongoose.model("Social", SocialMediaSchema);
